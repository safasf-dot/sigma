from flask import Flask, render_template, request, redirect, session, url_for, flash
import pymysql
from functools import wraps

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # 请修改为安全的密钥

def get_db_connection():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='123456',
        db='course_management',
        charset='utf8mb4',
        cursorclass=pymysql.cursors.DictCursor
    )

def login_required(role=None):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                return redirect(url_for('login'))
            if role and session.get('role') != role:
                return "无权限", 403
            return f(*args, **kwargs)
        return decorated_function
    return decorator

@app.route('/')
def index():
    if 'user_id' in session:
        if session.get('role') == 'admin':
            return redirect('/admin')
        elif session.get('role') == 'teacher':
            return redirect('/teacher')
        else:
            return redirect('/student')
    return redirect('/login')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form.get('role', 'student')
        if role not in ['student', 'teacher']:
            role = 'student'
        conn = get_db_connection()
        with conn.cursor() as cursor:
            try:
                cursor.execute("INSERT INTO users (username, password, role) VALUES (%s, %s, %s)", (username, password, role))
                conn.commit()
                flash('注册成功，请登录')
                return redirect('/login')
            except Exception as e:
                print(e)
                flash('用户名已存在')
        conn.close()
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE username=%s AND password=%s", (username, password))
            user = cursor.fetchone()
        conn.close()
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            if session['role'] == 'admin':
                return redirect('/admin')
            elif session['role'] == 'teacher':
                return redirect('/teacher')
            else:
                return redirect('/student')
        else:
            flash('登录失败')
            return render_template('login.html')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

# 学生功能
@app.route('/student')
@login_required(role='student')
def student_dashboard():
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT courses.*, users.username as teacher_name
            FROM courses
            LEFT JOIN users ON courses.teacher_id = users.id
        """)
        courses = cursor.fetchall()
        cursor.execute("SELECT course_id FROM enrollments WHERE user_id=%s", (session['user_id'],))
        enrolled = set(row['course_id'] for row in cursor.fetchall())
    conn.close()
    return render_template('student_dashboard.html', courses=courses, enrolled=enrolled)

@app.route('/student/enroll/<int:course_id>')
@login_required(role='student')
def enroll(course_id):
    conn = get_db_connection()
    with conn.cursor() as cursor:
        try:
            cursor.execute("INSERT IGNORE INTO enrollments (user_id, course_id) VALUES (%s, %s)", (session['user_id'], course_id))
            conn.commit()
        except:
            pass
    conn.close()
    return redirect('/student')

@app.route('/student/unenroll/<int:course_id>')
@login_required(role='student')
def unenroll(course_id):
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("DELETE FROM enrollments WHERE user_id=%s AND course_id=%s", (session['user_id'], course_id))
        conn.commit()
    conn.close()
    return redirect('/student')

@app.route('/student/enrollments')
@login_required(role='student')
def my_enrollments():
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT courses.*, users.username as teacher_name
            FROM courses
            LEFT JOIN users ON courses.teacher_id = users.id
            JOIN enrollments ON courses.id = enrollments.course_id
            WHERE enrollments.user_id = %s
        """, (session['user_id'],))
        my_courses = cursor.fetchall()
    conn.close()
    return render_template('my_enrollments.html', courses=my_courses)

# 老师功能
@app.route('/teacher')
@login_required(role='teacher')
def teacher_dashboard():
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM courses WHERE teacher_id = %s", (session['user_id'],))
        my_courses = cursor.fetchall()
    conn.close()
    return render_template('teacher_dashboard.html', courses=my_courses)

@app.route('/teacher/add_course', methods=['GET', 'POST'])
@login_required(role='teacher')
def teacher_add_course():
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        teacher_id = session['user_id']
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("INSERT INTO courses (name, teacher_id, description) VALUES (%s, %s, %s)", (name, teacher_id, description))
            conn.commit()
        conn.close()
        return redirect('/teacher')
    return render_template('teacher_add_course.html')

@app.route('/teacher/edit_course/<int:course_id>', methods=['GET', 'POST'])
@login_required(role='teacher')
def teacher_edit_course(course_id):
    conn = get_db_connection()
    with conn.cursor() as cursor:
        if request.method == 'POST':
            name = request.form['name']
            description = request.form['description']
            cursor.execute("UPDATE courses SET name=%s, description=%s WHERE id=%s AND teacher_id=%s",
                           (name, description, course_id, session['user_id']))
            conn.commit()
            conn.close()
            return redirect('/teacher')
        else:
            cursor.execute("SELECT * FROM courses WHERE id=%s AND teacher_id=%s", (course_id, session['user_id']))
            course = cursor.fetchone()
    conn.close()
    return render_template('teacher_edit_course.html', course=course)

@app.route('/teacher/delete_course/<int:course_id>')
@login_required(role='teacher')
def teacher_delete_course(course_id):
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("DELETE FROM courses WHERE id=%s AND teacher_id=%s", (course_id, session['user_id']))
        conn.commit()
    conn.close()
    return redirect('/teacher')

@app.route('/teacher/course_students/<int:course_id>')
@login_required(role='teacher')
def course_students(course_id):
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM courses WHERE id=%s AND teacher_id=%s", (course_id, session['user_id']))
        course = cursor.fetchone()
        if not course:
            conn.close()
            return "无权限", 403
        cursor.execute("""
            SELECT users.id, users.username
            FROM enrollments
            JOIN users ON enrollments.user_id = users.id
            WHERE enrollments.course_id = %s
        """, (course_id,))
        students = cursor.fetchall()
    conn.close()
    return render_template('course_students.html', course=course, students=students)

# 管理员功能
@app.route('/admin')
@login_required(role='admin')
def admin_dashboard():
    return render_template('admin_dashboard.html')

@app.route('/admin/courses')
@login_required(role='admin')
def manage_courses():
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT courses.*, users.username as teacher_name
            FROM courses
            LEFT JOIN users ON courses.teacher_id = users.id
        """)
        courses = cursor.fetchall()
    conn.close()
    return render_template('manage_courses.html', courses=courses)

@app.route('/admin/add_course', methods=['GET', 'POST'])
@login_required(role='admin')
def add_course():
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("SELECT id, username FROM users WHERE role='teacher'")
        teachers = cursor.fetchall()
        if request.method == 'POST':
            name = request.form['name']
            teacher_id = request.form['teacher_id']
            description = request.form['description']
            cursor.execute("INSERT INTO courses (name, teacher_id, description) VALUES (%s, %s, %s)", (name, teacher_id, description))
            conn.commit()
            conn.close()
            return redirect('/admin/courses')
    conn.close()
    return render_template('add_course.html', teachers=teachers)

@app.route('/admin/edit_course/<int:course_id>', methods=['GET', 'POST'])
@login_required(role='admin')
def edit_course(course_id):
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("SELECT id, username FROM users WHERE role='teacher'")
        teachers = cursor.fetchall()
        if request.method == 'POST':
            name = request.form['name']
            teacher_id = request.form['teacher_id']
            description = request.form['description']
            cursor.execute("UPDATE courses SET name=%s, teacher_id=%s, description=%s WHERE id=%s",
                           (name, teacher_id, description, course_id))
            conn.commit()
            conn.close()
            return redirect('/admin/courses')
        else:
            cursor.execute("SELECT * FROM courses WHERE id=%s", (course_id,))
            course = cursor.fetchone()
    conn.close()
    return render_template('edit_course.html', course=course, teachers=teachers)

@app.route('/admin/delete_course/<int:course_id>')
@login_required(role='admin')
def delete_course(course_id):
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("DELETE FROM courses WHERE id=%s", (course_id,))
        conn.commit()
    conn.close()
    return redirect('/admin/courses')

# -------- 分开管理学生和老师 --------

@app.route('/admin/manage_students')
@login_required(role='admin')
def manage_students():
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM users WHERE role='student'")
        users = cursor.fetchall()
    conn.close()
    return render_template('manage_students.html', users=users)

@app.route('/admin/manage_teachers')
@login_required(role='admin')
def manage_teachers():
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM users WHERE role='teacher'")
        users = cursor.fetchall()
    conn.close()
    return render_template('manage_teachers.html', users=users)

@app.route('/admin/delete_student/<int:user_id>')
@login_required(role='admin')
def delete_student(user_id):
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("DELETE FROM users WHERE id=%s AND role='student'", (user_id,))
        conn.commit()
    conn.close()
    return redirect('/admin/manage_students')

@app.route('/admin/delete_teacher/<int:user_id>')
@login_required(role='admin')
def delete_teacher(user_id):
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("DELETE FROM users WHERE id=%s AND role='teacher'", (user_id,))
        conn.commit()
    conn.close()
    return redirect('/admin/manage_teachers')

# -------- 选课记录管理 --------

@app.route('/admin/enrollments')
@login_required(role='admin')
def manage_enrollments():
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT enrollments.id, users.username, courses.name AS course_name
            FROM enrollments
            JOIN users ON enrollments.user_id = users.id
            JOIN courses ON enrollments.course_id = courses.id
        """)
        enrollments = cursor.fetchall()
    conn.close()
    return render_template('manage_enrollments.html', enrollments=enrollments)

@app.route('/admin/delete_enrollment/<int:enrollment_id>')
@login_required(role='admin')
def delete_enrollment(enrollment_id):
    conn = get_db_connection()
    with conn.cursor() as cursor:
        cursor.execute("DELETE FROM enrollments WHERE id=%s", (enrollment_id,))
        conn.commit()
    conn.close()
    return redirect('/admin/enrollments')

if __name__ == '__main__':
    app.run(debug=True)